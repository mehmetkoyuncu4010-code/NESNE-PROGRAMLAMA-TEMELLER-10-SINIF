﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Drawing.Printing; 
namespace deneme_4
{
    public partial class FormSoruEkle : Form
    {
        private string baglantiCumlesi = "Server=localhost;Database=SoruBankasiDB;Uid=root;Pwd=GTARLLK123;";
        public FormSoruEkle()
        {
            InitializeComponent();
        }

        private void FormSoruEkle_Load(object sender, EventArgs e)
        {
            KonuListesiniDoldur();
            TumSorulariListele();
        }
        private void KonuListesiniDoldur()
        {
            try
            {
                using (MySqlConnection baglanti = new MySqlConnection(baglantiCumlesi))
                {
                    baglanti.Open();
                    string sorgu = "SELECT KonuID, KonuAdi FROM Konular";

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(sorgu, baglanti))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        cmbKategori.DataSource = dt;
                        cmbKategori.DisplayMember = "KonuAdi"; // Ekranda konu adı gözükür
                        cmbKategori.ValueMember = "KonuID";    // Arka planda ID değeri tutulur
                        cmbKategori.SelectedIndex = -1;        // İlk açılışta içi boş seçilmemiş gelsin
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Konu listesi yüklenirken hata oluştu: " + ex.Message, "Bağlantı Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void TumSorulariListele()
        {
            try
            {
                using (MySqlConnection baglanti = new MySqlConnection(baglantiCumlesi))
                {
                    baglanti.Open();

                    // Sadece içi dolu olan ve düzgün kaydedilmiş soruları getiren sorgu
                    string sorgu = "SELECT SoruID, SoruMetni, SecenekA, SecenekB, SecenekC, SecenekD, DogruCevap FROM Sorular WHERE SoruMetni IS NOT NULL AND SoruMetni != ''";

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(sorgu, baglanti))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        dgvTumSorular.DataSource = null;
                        dgvTumSorular.DataSource = dt;

                        // Ekrana sığma ve görsel düzen ayarları
                        dgvTumSorular.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None; // Elle müdahale için önce kapattık

                        if (dgvTumSorular.Columns.Count > 0)
                        {
                            dgvTumSorular.Columns["SoruID"].Width = 60;
                            dgvTumSorular.Columns["SoruMetni"].Width = 250; // Soru metnini genişlettik
                            dgvTumSorular.Columns["SecenekA"].Width = 100;
                            dgvTumSorular.Columns["SecenekB"].Width = 100;
                            dgvTumSorular.Columns["SecenekC"].Width = 100;
                            dgvTumSorular.Columns["SecenekD"].Width = 100;
                            dgvTumSorular.Columns["DogruCevap"].Width = 80;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sorular listelenirken hata oluştu:\n" + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnKaydet_Click(object sender, EventArgs e)
        {
        }
        private void SinavKagidiTasarimi(object sender, PrintPageEventArgs e)
        {
            // Font ve Yazı Biçimleri
            Font baslikFontu = new Font("Segoe UI", 16, FontStyle.Bold);
            Font altBaslikFontu = new Font("Segoe UI", 11, FontStyle.Italic);
            Font soruFontu = new Font("Segoe UI", 11, FontStyle.Bold);
            Font sikFontu = new Font("Segoe UI", 10, FontStyle.Regular);

            Brush kalem = Brushes.Black; // Yazı rengi siyah olacak

            // Sayfa Koordinatları (X: Soldan Sağa, Y: Yukarıdan Aşağıya mesafe)
            int x = 50;  // Sol kenar boşluğu
            int y = 50;  // Üst kenar boşluğu
            int sayfaGenisligi = e.PageBounds.Width - 100; // Çizgi için genişlik

            // --- BAŞLIK ALANI ---
            e.Graphics.DrawString("T.C. MİLLÎ EĞİTİM BAKANLIĞI", altBaslikFontu, kalem, x + 250, y);
            y += 25;
            e.Graphics.DrawString("10. SINIF MATEMATİK DERSİ TARAMA SINAVI", baslikFontu, kalem, x + 80, y);
            y += 35;

            // Öğrenci Ad / Soyad / İmza Alanı (Okul sınavlarındaki gibi şık bir kutu)
            e.Graphics.DrawString("Adı Soyadı: ...................................................", altBaslikFontu, kalem, x, y);
            e.Graphics.DrawString("Sınıfı / No: .........................", altBaslikFontu, kalem, x + 450, y);
            y += 25;

            // Araya estetik bir siyah çizgi çekiyoruz
            e.Graphics.DrawLine(Pens.Black, x, y, x + sayfaGenisligi, y);
            y += 30; // Çizgiden sonra boşluk bırak

            // --- SORULARI VERİTABANINDAN (DATAGRİD'DEN) ÇEKİP A4'E YAZDIRMA ---
            int soruNo = 1;

            foreach (DataGridViewRow satir in dgvTumSorular.Rows)
            {
                // Boş satırları atla
                if (satir.Cells["SoruMetni"].Value == null) continue;

                string soruMetni = satir.Cells["SoruMetni"].Value.ToString();
                string a = satir.Cells["SecenekA"].Value.ToString();
                string b = satir.Cells["SecenekB"].Value.ToString();
                string c = satir.Cells["SecenekC"].Value.ToString();
                string d = satir.Cells["SecenekD"].Value.ToString();

                // 1. Soru Metnini Yazdır
                e.Graphics.DrawString($"Soru {soruNo}) {soruMetni}", soruFontu, kalem, x, y);
                y += 25; // Soru metninden sonra şıklar için aşağı kaydır

                // 2. Şıkları Yan Yana veya Alt Alta Şık Duracak Şekilde Yazdır (A ve B yan yana, C ve D yan yana)
                e.Graphics.DrawString($"A) {a}", sikFontu, kalem, x + 20, y);
                e.Graphics.DrawString($"B) {b}", sikFontu, kalem, x + 350, y);
                y += 20; // Diğer şıklar için aşağı kaydır

                e.Graphics.DrawString($"C) {c}", sikFontu, kalem, x + 20, y);
                e.Graphics.DrawString($"D) {d}", sikFontu, kalem, x + 350, y);

                y += 40; // Bir sonraki soruya geçmeden önce temiz bir boşluk bırak
                soruNo++;

                // Eğer sorular sayfaya sığmayacak kadar çoksa (Güvenlik Önlemi)
                if (y > e.PageBounds.Height - 100)
                {
                    break; // İlk sayfa dolunca şimdilik kes (Ödev seviyesi için tek sayfa idealdir)
                }
            }
        }






        private void btnKaydet_Click_1(object sender, EventArgs e)
        {

        }

        private void btnKaydet_Click_2(object sender, EventArgs e)
        {
            // Güvenlik: Boş alan kontrolü
            if (string.IsNullOrEmpty(rtbSoruMetni.Text) || string.IsNullOrEmpty(txtA.Text) ||
                string.IsNullOrEmpty(txtB.Text) || string.IsNullOrEmpty(txtC.Text) ||
                string.IsNullOrEmpty(txtD.Text) || cmbDogruCevap.SelectedIndex == -1 || cmbKategori.SelectedIndex == -1)
            {
                MessageBox.Show("Lütfen tüm alanları eksiksiz doldurunuz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection baglanti = new MySqlConnection(baglantiCumlesi))
                {
                    baglanti.Open();

                    // Veritabanına veri ekleme SQL sorgusu
                    string sorgu = "INSERT INTO Sorular (SoruMetni, SecenekA, SecenekB, SecenekC, SecenekD, DogruCevap, KonuID) " +
                                   "VALUES (@metin, @a, @b, @c, @d, @dogru, @konuId)";

                    using (MySqlCommand komut = new MySqlCommand(sorgu, baglanti))
                    {
                        // SQL Injection korumalı parametreler
                        komut.Parameters.AddWithValue("@metin", rtbSoruMetni.Text);
                        komut.Parameters.AddWithValue("@a", txtA.Text);
                        komut.Parameters.AddWithValue("@b", txtB.Text);
                        komut.Parameters.AddWithValue("@c", txtC.Text);
                        komut.Parameters.AddWithValue("@d", txtD.Text);
                        komut.Parameters.AddWithValue("@dogru", cmbDogruCevap.SelectedItem.ToString());
                        komut.Parameters.AddWithValue("@konuId", cmbKategori.SelectedValue); // ComboBox'tan seçilen konunun benzersiz ID'si

                        komut.ExecuteNonQuery(); // Sorguyu çalıştırır
                    }
                }

                MessageBox.Show("Soru başarıyla kaydedildi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // [SİHİRLİ DOKUNUŞ]: Soru eklenir eklenmez tabloyu aşağıda anında günceller!
                TumSorulariListele();

                // Kutuları temizleme işlemi
                rtbSoruMetni.Clear(); txtA.Clear(); txtB.Clear(); txtC.Clear(); txtD.Clear();
                cmbDogruCevap.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Soru kaydedilirken hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            // DataGridView'den satır seçilmiş mi kontrol ediyoruz
            if (dgvTumSorular.CurrentRow == null)
            {
                MessageBox.Show("Lütfen silmek istediğiniz soruyu tablodan seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Seçili satırdaki "SoruID" hücre değerini alıyoruz
            int seciliSoruID = Convert.ToInt32(dgvTumSorular.CurrentRow.Cells["SoruID"].Value);

            // Kullanıcıya emin olup olmadığını soralım (Güvenlik önlemi)
            DialogResult onay = MessageBox.Show("Bu soruyu kalıcı olarak silmek istediğinize emin misiniz?", "Silme Onayı", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

            if (onay == DialogResult.OK)
            {
                try
                {
                    using (MySqlConnection baglanti = new MySqlConnection(baglantiCumlesi))
                    {
                        baglanti.Open();
                        // ID'ye göre silme sorgusu
                        string sorgu = "DELETE FROM Sorular WHERE SoruID = @id";

                        using (MySqlCommand komut = new MySqlCommand(sorgu, baglanti))
                        {
                            komut.Parameters.AddWithValue("@id", seciliSoruID);
                            komut.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Soru başarıyla silindi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Silme işleminden sonra ekrandaki listeyi güncelliyoruz
                    TumSorulariListele();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Silme işlemi sırasında hata oluştu: " + ex.Message);
                }
            }
        }

        private void btnYazdir_Click(object sender, EventArgs e)
        {
            // Eğer tabloda hiç soru yoksa işlemi iptal et
            if (dgvTumSorular.Rows.Count == 0)
            {
                MessageBox.Show("PDF'e aktarılacak hiç soru bulunamadı!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                PrintDocument pd = new PrintDocument();
                pd.PrintPage += new PrintPageEventHandler(SinavKagidiTasarimi);

                // --- DOĞRUDAN PDF YAPMA AYARI ---
                // Windows'un standart PDF yazıcısını seçiyoruz
                pd.PrinterSettings.PrinterName = "Microsoft Print to PDF";

                // Kullanıcıya PDF'i nereye kaydedeceğini sormak için Dosya Kaydet penceresi açıyoruz
                SaveFileDialog dosyaKaydet = new SaveFileDialog();
                dosyaKaydet.Filter = "PDF Dosyası (*.pdf)|*.pdf";
                dosyaKaydet.Title = "Sınav Kağıdını PDF Olarak Kaydet";
                dosyaKaydet.FileName = "10_Sinif_Matematik_Tarama_Sinavi.pdf"; // Varsayılan dosya adı

                if (dosyaKaydet.ShowDialog() == DialogResult.OK)
                {
                    // Yazıcı çıktısını fiziksel kağıda değil, kullanıcının seçtiği PDF dosyasına yönlendiriyoruz
                    pd.PrinterSettings.PrintToFile = true;
                    pd.PrinterSettings.PrintFileName = dosyaKaydet.FileName;

                    // PDF oluşturma işlemini tetikliyoruz
                    pd.Print();

                    MessageBox.Show("Sınav kağıdı başarıyla PDF olarak kaydedildi!", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PDF oluşturulurken bir hata oluştu:\n" + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    }

        
    
    


    

