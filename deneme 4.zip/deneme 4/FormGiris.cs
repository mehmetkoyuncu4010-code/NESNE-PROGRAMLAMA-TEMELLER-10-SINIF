﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;
using System.Text;
namespace deneme_4
{
    public partial class FormGiris : Form
    {
        private string baglantiCumlesi = "Server=localhost;Database=SoruBankasiDB;Uid=root;Pwd=GTARLLK123;";
        public FormGiris()
        {
            InitializeComponent();
        }

        private void FormGiris_Load(object sender, EventArgs e)
        {

        }
        private string SifreyiGuzellestirMD5(string sifre)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] girisBaytlari = Encoding.UTF8.GetBytes(sifre);
                byte[] hashBaytlari = md5.ComputeHash(girisBaytlari);

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBaytlari.Length; i++)
                {
                    sb.Append(hashBaytlari[i].ToString("x2"));
                }
                return sb.ToString(); // Artık şifre 32 karakterli karmaşık bir kod oldu!
            }
        }
        private void btnGiris_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection baglanti = new MySqlConnection(baglantiCumlesi))
                {
                    baglanti.Open();
                    // Kullanıcı adı ve şifre veritabanında eşleşiyor mu?
                    // BINARY komutu sayesinde 'Admin' ile 'admin' artık farklı kabul edilecek!
                    string sorgu = "SELECT Ad, Soyad FROM Kullanicilar WHERE BINARY KullaniciAdi = @kullaniciAdi AND Sifre = @sifre";

                    using (MySqlCommand komut = new MySqlCommand(sorgu, baglanti))
                    {
                        komut.Parameters.AddWithValue("@kullaniciAdi", txtKullaniciAdi.Text);
                        string girisSifresiSifreli = SifreyiGuzellestirMD5(txtSifre.Text);
                        komut.Parameters.AddWithValue("@sifre", girisSifresiSifreli);

                        using (MySqlDataReader reader = komut.ExecuteReader())
                        {
                            if (reader.Read()) // Eğer veritabanında böyle biri varsa
                            {
                                string adSoyad = reader["Ad"].ToString() + " " + reader["Soyad"].ToString();
                                MessageBox.Show("Sisteme hoş geldiniz, Sayın " + adSoyad, "Giriş Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Giriş formu gizlenir ve 4 butonun olduğu Ana Menü açılır
                                this.Hide();
                                Form1 anaMenu = new Form1();
                                anaMenu.ShowDialog();
                                this.Close(); // Ana menü kapanınca program tamamen kapanır
                            }
                            else
                            {
                                MessageBox.Show("Kullanıcı adı veya şifre hatalı!", "Giriş Başarısız", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bağlantı hatası: " + ex.Message);
            }
        }

        private void btnKayitOl_Click(object sender, EventArgs e)
        {
            FormKayit kayitFormu = new FormKayit();
            kayitFormu.ShowDialog();
        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

