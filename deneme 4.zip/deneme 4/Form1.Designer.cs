﻿namespace deneme_4
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSaymaOlasilik = new System.Windows.Forms.Button();
            this.btnFonksiyonlar = new System.Windows.Forms.Button();
            this.btnPolinomlar = new System.Windows.Forms.Button();
            this.btnSoruEkleFormu = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnTestCozModulu = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSaymaOlasilik
            // 
            this.btnSaymaOlasilik.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSaymaOlasilik.Location = new System.Drawing.Point(12, 21);
            this.btnSaymaOlasilik.Name = "btnSaymaOlasilik";
            this.btnSaymaOlasilik.Size = new System.Drawing.Size(173, 76);
            this.btnSaymaOlasilik.TabIndex = 0;
            this.btnSaymaOlasilik.Text = "Sayma ve Olasılık";
            this.btnSaymaOlasilik.UseVisualStyleBackColor = true;
            this.btnSaymaOlasilik.Click += new System.EventHandler(this.btnSaymaOlasilik_Click);
            // 
            // btnFonksiyonlar
            // 
            this.btnFonksiyonlar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnFonksiyonlar.Location = new System.Drawing.Point(213, 21);
            this.btnFonksiyonlar.Name = "btnFonksiyonlar";
            this.btnFonksiyonlar.Size = new System.Drawing.Size(178, 76);
            this.btnFonksiyonlar.TabIndex = 1;
            this.btnFonksiyonlar.Text = "Fonksiyonlar";
            this.btnFonksiyonlar.UseVisualStyleBackColor = true;
            this.btnFonksiyonlar.Click += new System.EventHandler(this.btnFonksiyonlar_Click);
            // 
            // btnPolinomlar
            // 
            this.btnPolinomlar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnPolinomlar.Location = new System.Drawing.Point(12, 103);
            this.btnPolinomlar.Name = "btnPolinomlar";
            this.btnPolinomlar.Size = new System.Drawing.Size(173, 80);
            this.btnPolinomlar.TabIndex = 2;
            this.btnPolinomlar.Text = "Polinomlar";
            this.btnPolinomlar.UseVisualStyleBackColor = true;
            this.btnPolinomlar.Click += new System.EventHandler(this.btnPolinomlar_Click);
            // 
            // btnSoruEkleFormu
            // 
            this.btnSoruEkleFormu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSoruEkleFormu.Location = new System.Drawing.Point(213, 103);
            this.btnSoruEkleFormu.Name = "btnSoruEkleFormu";
            this.btnSoruEkleFormu.Size = new System.Drawing.Size(178, 80);
            this.btnSoruEkleFormu.TabIndex = 3;
            this.btnSoruEkleFormu.Text = "Soru Kaydı";
            this.btnSoruEkleFormu.UseVisualStyleBackColor = true;
            this.btnSoruEkleFormu.Click += new System.EventHandler(this.btnSoruEkleFormu_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnTestCozModulu);
            this.groupBox1.Controls.Add(this.btnSoruEkleFormu);
            this.groupBox1.Controls.Add(this.btnSaymaOlasilik);
            this.groupBox1.Controls.Add(this.btnFonksiyonlar);
            this.groupBox1.Controls.Add(this.btnPolinomlar);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(432, 292);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ANA MENÜ";
            // 
            // btnTestCozModulu
            // 
            this.btnTestCozModulu.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnTestCozModulu.Location = new System.Drawing.Point(117, 189);
            this.btnTestCozModulu.Name = "btnTestCozModulu";
            this.btnTestCozModulu.Size = new System.Drawing.Size(172, 72);
            this.btnTestCozModulu.TabIndex = 4;
            this.btnTestCozModulu.Text = "Test Çöz";
            this.btnTestCozModulu.UseVisualStyleBackColor = true;
            this.btnTestCozModulu.Click += new System.EventHandler(this.btnTestCozModulu_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(432, 292);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSaymaOlasilik;
        private System.Windows.Forms.Button btnFonksiyonlar;
        private System.Windows.Forms.Button btnPolinomlar;
        private System.Windows.Forms.Button btnSoruEkleFormu;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnTestCozModulu;
    }
}

