﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
namespace deneme_4
{
    public partial class FormTestCoz : Form
    {
        private string baglantiCumlesi = "Server=localhost;Database=SoruBankasiDB;Uid=root;Pwd=GTARLLK123;";
        private DataTable dtSorular = new DataTable();
        private int mevcutSoruIndeks = 0;
        private int dogruSayisi = 0;
        private int yanlisSayisi = 0;
        private string dogruCevap = "";
        public FormTestCoz()
        {
            InitializeComponent();
        }
        private void KonulariGetir()
        {
            try
            {
                using (MySqlConnection baglanti = new MySqlConnection(baglantiCumlesi))
                {
                    baglanti.Open();
                    string sorgu = "SELECT KonuID, KonuAdi FROM Konular";
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(sorgu, baglanti))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        cmbTestKategori.DataSource = dt;
                        cmbTestKategori.DisplayMember = "KonuAdi";
                        cmbTestKategori.ValueMember = "KonuID";
                        cmbTestKategori.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Konular yüklenirken hata: " + ex.Message);
            }
        }
        private void FormTestCoz_Load(object sender, EventArgs e)
        {
            KonulariGetir();
            btnSonrakiSoru.Enabled = false;
        }
        private void SoruGoster()
        {
            if (mevcutSoruIndeks < dtSorular.Rows.Count)
            {
                // İşaretlemeleri temizle
                rdbA.Checked = false; rdbB.Checked = false; rdbC.Checked = false; rdbD.Checked = false;

                DataRow satir = dtSorular.Rows[mevcutSoruIndeks];

                // Form başlığına kaçıncı soruda olduğunu yazalım
                this.Text = $"Soru: {mevcutSoruIndeks + 1} / {dtSorular.Rows.Count}";

                // Soru ve şıkları form elemanlarına aktar
                rtbTestSoru.Text = satir["SoruMetni"].ToString();
                rdbA.Text = "A) " + satir["SecenekA"].ToString();
                rdbB.Text = "B) " + satir["SecenekB"].ToString();
                rdbC.Text = "C) " + satir["SecenekC"].ToString();
                rdbD.Text = "D) " + satir["SecenekD"].ToString();

                dogruCevap = satir["DogruCevap"].ToString().Trim().ToUpper();
            }
            else
            {
                // Sorular bittiyse sonucu göster
                MessageBox.Show($"Test Bitti!\n\nTebrikler !\nDoğru Sayısı: {dogruSayisi}\nYanlış Sayısı: {yanlisSayisi}",
                                "Sınav Sonucu", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Formu eski haline getir
                btnTestiBaslat.Enabled = true;
                btnSonrakiSoru.Enabled = false;
                cmbTestKategori.Enabled = true;
                rtbTestSoru.Clear();
                rdbA.Text = "A"; rdbB.Text = "B"; rdbC.Text = "C"; rdbD.Text = "D";
                this.Text = "Test Çözme Modülü";
            }
        }
        private void btnTestiBaslat_Click(object sender, EventArgs e)
        {
            if (cmbTestKategori.SelectedIndex == -1)
            {
                MessageBox.Show("Lütfen önce test çözmek istediğiniz konuyu seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection baglanti = new MySqlConnection(baglantiCumlesi))
                {
                    baglanti.Open();
                    // Seçilen konudan RASTGELE (ORDER BY RAND()) en fazla 10 soru getirir
                    string sorgu = "SELECT SoruMetni, SecenekA, SecenekB, SecenekC, SecenekD, DogruCevap " +
                                   "FROM Sorular WHERE KonuID = @konuId ORDER BY RAND() LIMIT 10";

                    using (MySqlCommand komut = new MySqlCommand(sorgu, baglanti))
                    {
                        komut.Parameters.AddWithValue("@konuId", cmbTestKategori.SelectedValue);
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(komut))
                        {
                            dtSorular.Clear();
                            adapter.Fill(dtSorular);
                        }
                    }
                }

                if (dtSorular.Rows.Count == 0)
                {
                    MessageBox.Show("Bu konuya ait henüz soru eklenmemiş!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Sınav değişkenlerini sıfırla ve ilk soruyu yükle
                mevcutSoruIndeks = 0;
                dogruSayisi = 0;
                yanlisSayisi = 0;
                btnSonrakiSoru.Enabled = true;
                btnTestiBaslat.Enabled = false; // Test esnasında tekrar başlatılamasın
                cmbTestKategori.Enabled = false;

                SoruGoster();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Test başlatılamadı: " + ex.Message);
            }
        }

        private void btnSonrakiSoru_Click(object sender, EventArgs e)
        {
            // Kullanıcı bir şık seçti mi kontrolü
            string secilenCevap = "";
            if (rdbA.Checked) secilenCevap = "A";
            else if (rdbB.Checked) secilenCevap = "B";
            else if (rdbC.Checked) secilenCevap = "C";
            else if (rdbD.Checked) secilenCevap = "D";

            if (secilenCevap == "")
            {
                MessageBox.Show("Lütfen bir şık işaretleyin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Doğru-Yanlış kontrolü yapılıyor
            if (secilenCevap == dogruCevap)
            {
                dogruSayisi++;
            }
            else
            {
                yanlisSayisi++;
            }

            // Bir sonraki soruya geç ve ekrana bas
            mevcutSoruIndeks++;
            SoruGoster();
        }
    }
}
        
    
    

