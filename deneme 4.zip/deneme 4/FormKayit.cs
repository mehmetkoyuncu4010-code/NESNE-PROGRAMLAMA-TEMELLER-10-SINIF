﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;
using System.Text;
namespace deneme_4
{
    public partial class FormKayit : Form
    {
        private string baglantiCumlesi = "Server=localhost;Database=SoruBankasiDB;Uid=root;Pwd=GTARLLK123;";
        public FormKayit()
        {
            InitializeComponent();
        }

        private void FormKayit_Load(object sender, EventArgs e)
        {

        }
        private string SifreyiGuzellestirMD5(string sifre)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] girisBaytlari = Encoding.UTF8.GetBytes(sifre);
                byte[] hashBaytlari = md5.ComputeHash(girisBaytlari);

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBaytlari.Length; i++)
                {
                    sb.Append(hashBaytlari[i].ToString("x2"));
                }
                return sb.ToString(); // Artık şifre 32 karakterli karmaşık bir kod oldu!
            }
        }
        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (txtSifre.Text.Length < 5)
            {
                MessageBox.Show("Şifreniz en az 5 karakterden oluşmalıdır!", "Güvenlik Uyarısı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrEmpty(txtAd.Text) || string.IsNullOrEmpty(txtSoyad.Text) ||
                string.IsNullOrEmpty(txtKullaniciAdi.Text) || string.IsNullOrEmpty(txtSifre.Text))
            {
                MessageBox.Show("Lütfen tüm alanları doldurunuz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection baglanti = new MySqlConnection(baglantiCumlesi))
                {
                    baglanti.Open();

                    // Bu kullanıcı adı daha önce alınmış mı kontrol edelim
                    string kontrolSorgusu = "SELECT COUNT(*) FROM Kullanicilar WHERE KullaniciAdi = @kullaniciAdi";
                    using (MySqlCommand kontrolKomut = new MySqlCommand(kontrolSorgusu, baglanti))
                    {
                        kontrolKomut.Parameters.AddWithValue("@kullaniciAdi", txtKullaniciAdi.Text);
                        int varMi = Convert.ToInt32(kontrolKomut.ExecuteScalar());

                        if (varMi > 0)
                        {
                            MessageBox.Show("Bu kullanıcı adı zaten alınmış!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Kullanıcıyı ekleme sorgusu
                    string sorgu = "INSERT INTO Kullanicilar (Ad, Soyad, KullaniciAdi, Sifre) VALUES (@ad, @soyad, @kullaniciAdi, @sifre)";
                    using (MySqlCommand komut = new MySqlCommand(sorgu, baglanti))
                    {
                        komut.Parameters.AddWithValue("@ad", txtAd.Text);
                        komut.Parameters.AddWithValue("@soyad", txtSoyad.Text);
                        komut.Parameters.AddWithValue("@kullaniciAdi", txtKullaniciAdi.Text);
                        string sifreliSifre = SifreyiGuzellestirMD5(txtSifre.Text);
                        komut.Parameters.AddWithValue("@sifre", sifreliSifre);

                        komut.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Kayıt başarıyla oluşturuldu! Giriş yapabilirsiniz.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close(); // Kayıt başarılı olunca formu kapatır
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kayıt hatası: " + ex.Message);
            }
        }

        private void txtKullaniciAdi_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSoyad_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {
            string sifre = txtSifre.Text;

            if (string.IsNullOrEmpty(sifre))
            {
                lblSifreDurumu.Text = "Şifre Zorluğu: Henüz girilmedi";
                lblSifreDurumu.ForeColor = System.Drawing.Color.White;
                return;
            }

            if (sifre.Length < 5)
            {
                lblSifreDurumu.Text = "Şifre Zorluğu: Çok Kısa! (En az 5 hane)";
                lblSifreDurumu.ForeColor = System.Drawing.Color.Red;
                return;
            }

            // Zorluk kriterlerini kontrol ediyoruz
            bool rakamVar = false;
            bool harfVar = false;
            bool ozelKarakterVar = false;

            foreach (char c in sifre)
            {
                if (char.IsDigit(c)) rakamVar = true;
                if (char.IsLetter(c)) harfVar = true;
                if (char.IsSymbol(c) || char.IsPunctuation(c)) ozelKarakterVar = true;
            }

            // Duruma göre ekranda zorluğu gösteriyoruz
            if (rakamVar && harfVar && ozelKarakterVar && sifre.Length >= 8)
            {
                lblSifreDurumu.Text = "Şifre Zorluğu: Güçlü / Zor 🔒";
                lblSifreDurumu.ForeColor = System.Drawing.Color.LimeGreen;
            }
            else if (rakamVar && harfVar)
            {
                lblSifreDurumu.Text = "Şifre Zorluğu: Orta Seviye ⚠️";
                lblSifreDurumu.ForeColor = System.Drawing.Color.Orange;
            }
            else
            {
                lblSifreDurumu.Text = "Şifre Zorluğu: Kolay / Zayıf ❌";
                lblSifreDurumu.ForeColor = System.Drawing.Color.Tomato;
            }
        }
    }
    }

        
    

