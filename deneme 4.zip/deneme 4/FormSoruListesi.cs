﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace deneme_4
{
    public partial class FormSoruListesi : Form
    {
        private string baglantiCumlesi = "Server=localhost;Database=SoruBankasiDB;Uid=root;Pwd=GTARLLK123;";

        public string SecilenKategori { get; set; }
        public FormSoruListesi()
        {
            InitializeComponent();
        }

        private void FormSoruListesi_Load(object sender, EventArgs e)
        {
            this.Text = SecilenKategori + " Soruları";
            SorulariGetir();
        }
        private void SorulariGetir()
        {
            try
            {
                using (MySqlConnection baglanti = new MySqlConnection(baglantiCumlesi))
                {
                    baglanti.Open();
                    // Sorular ile Konular tablosunu INNER JOIN ile birbirine bağlıyoruz
                    string sorgu = "SELECT s.SoruID, s.SoruMetni, s.SecenekA, s.SecenekB, s.SecenekC, s.SecenekD, s.DogruCevap " +
                                   "FROM Sorular s " +
                                   "INNER JOIN Konular k ON s.KonuID = k.KonuID " +
                                   "WHERE k.KonuAdi = @kategoriAdi";

                    using (MySqlCommand komut = new MySqlCommand(sorgu, baglanti))
                    {
                        komut.Parameters.AddWithValue("@kategoriAdi", SecilenKategori);

                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(komut))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            dgvSorular.DataSource = dt; // Veriler datagridview'e basılıyor
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veri yükleme hatası: " + ex.Message);
            }
        }
    }
}
    

