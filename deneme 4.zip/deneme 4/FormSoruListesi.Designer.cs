﻿namespace deneme_4
{
    partial class FormSoruListesi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvSorular = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSorular)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvSorular
            // 
            this.dgvSorular.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSorular.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSorular.Location = new System.Drawing.Point(0, 0);
            this.dgvSorular.Name = "dgvSorular";
            this.dgvSorular.Size = new System.Drawing.Size(885, 146);
            this.dgvSorular.TabIndex = 0;
            // 
            // FormSoruListesi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 146);
            this.Controls.Add(this.dgvSorular);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormSoruListesi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormSoruListesi";
            this.Load += new System.EventHandler(this.FormSoruListesi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSorular)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSorular;
    }
}