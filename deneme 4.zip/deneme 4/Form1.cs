﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace deneme_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSaymaOlasilik_Click(object sender, EventArgs e)
        {
            FormSoruListesi liste = new FormSoruListesi();
            liste.SecilenKategori = "Sayma ve Olasılık";
            liste.ShowDialog();
        }

        private void btnFonksiyonlar_Click(object sender, EventArgs e)
        {
            FormSoruListesi liste = new FormSoruListesi();
            liste.SecilenKategori = "Fonksiyonlar";
            liste.ShowDialog();
        }

        private void btnPolinomlar_Click(object sender, EventArgs e)
        {
            FormSoruListesi liste = new FormSoruListesi();
            liste.SecilenKategori = "Polinomlar";
            liste.ShowDialog();
        }

        private void btnSoruEkleFormu_Click(object sender, EventArgs e)
        {
            FormSoruEkle ekleForm = new FormSoruEkle();
            ekleForm.ShowDialog();
        }

        private void btnTestCozModulu_Click(object sender, EventArgs e)
        {
            FormTestCoz testFormu = new FormTestCoz();
            testFormu.ShowDialog(); // Test çözme ekranını açar
        }
    }
}
